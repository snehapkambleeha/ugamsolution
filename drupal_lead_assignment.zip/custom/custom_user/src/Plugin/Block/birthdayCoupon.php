<?php
namespace Drupal\custom_user\Plugin\Block;
use Drupal\Core\Block\BlockBase;

/**
 * Description of TopHeader
 *
 * @author Sneha
 * @Block(
 *   id = "birthday_coupon",
 *   admin_label = @Translation("Birthday Coupon Block"),
 *   category = @Translation("Birthday Coupon Block")
 * )
 */
class birthdayCoupon extends BlockBase{

  public function build() {

  	$data = [];
  	$birthday = FALSE;
  	$user = \Drupal\user\Entity\User::load(\Drupal::currentUser()->id());
	// retrieve field data from that user
	$fav_pizzaId = $user->get("field_pizza")->target_id;
	$user_dob = $user->get("field_date_of_birth")->value;
 	$fav_pizza = \Drupal\taxonomy\Entity\Term::load($fav_pizzaId)->get('name')->value;

 	$current_date = date("d") ."-".date("m"); 
	$user_dob_str = strtotime($user_dob);
  	$user_dob_details = date('d', $user_dob_str) ."-".date('m', $user_dob_str);

	if($current_date == $user_dob_details) {
	  $birthday = TRUE;
	}

	$data['birthday'] = $birthday;
	$data['fav_pizza'] = $fav_pizza;
	return [
      '#theme' => 'custom_user_birthday_coupon_template',
      '#data' => $data,
      '#cache' => ['max-age' => 0],
    ];
  }

}
